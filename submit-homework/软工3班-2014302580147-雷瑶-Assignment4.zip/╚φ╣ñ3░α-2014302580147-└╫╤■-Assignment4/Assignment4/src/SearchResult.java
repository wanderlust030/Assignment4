
public class SearchResult {
	private ProfessorInfo pi;
	private double TF;

	public SearchResult(ProfessorInfo pi,double TF){
		this.pi = pi;
		this.TF = TF;
	}

	public ProfessorInfo getPi() {
		return pi;
	}

	public void setPi(ProfessorInfo pi) {
		this.pi = pi;
	}

	public double getTF() {
		return TF;
	}

	public void setTF(double tF) {
		TF = tF;
	}
}
