import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class KeywordsProcessor {
	private static Set<String> stopwords = new HashSet<String>();
	private List<String> keywords = new ArrayList<String>();
	private ArrayList<ProfessorInfo> matchingInfos = new ArrayList<ProfessorInfo>();
	private ArrayList<SearchResult> searchResultList = new ArrayList<SearchResult>();
	
	//����stopwords
	public void getStopwords() throws FileNotFoundException{		
		Scanner sc = new Scanner(new File("stopwords.txt"));
		while (sc.hasNextLine()) {
		  stopwords.add(sc.nextLine());
		}
		sc.close();					
	}
	
	//�������������е�stopwords���õ�keywords
	public void KeywordsExcludeStopwords(String input){
		keywords.clear();
		String[] words = input.split(" ");
		for(String e:words){
			if(!stopwords.contains(e)){
				keywords.add(e);
			}
		}
	}
	
	//����ƥ��
	public void getMatchingInfos(ArrayList<ProfessorInfo> infos){
		matchingInfos.clear();
		for(ProfessorInfo info:infos){
			String s = info.getName()+info.getEducationBackground()+info.getResearchInterests()+info.getEmail()+info.getPhone();
			for(String keyword:keywords){
				if(s.contains(keyword) && !matchingInfos.contains(info)){
					matchingInfos.add(info);
				}
			}
		}
	}
	
	//����TFֵ
	public double calTF(List<String> sepWords){
		double totalWordNum = (double) sepWords.size();
		double wordNum = 0.0;
		for(String sepWord:sepWords){
			for(String keyword:keywords){
				if(sepWord.contains(keyword)){
					wordNum++;
				}
			}
		}
		return wordNum/totalWordNum;
	}
	
	//�õ��������������TFֵ
	public void getAllTF(){
		searchResultList.clear();
		for(ProfessorInfo matchingInfo:matchingInfos){
			String[] rawWords = (matchingInfo.getName()+matchingInfo.getEducationBackground()
			+matchingInfo.getResearchInterests()+matchingInfo.getEmail()+matchingInfo.getPhone()).split(" ");
			List<String> sepWords = new ArrayList<String>();
			for(String rawWord:rawWords){
				if(!stopwords.contains(rawWord)){
					sepWords.add(rawWord);
				}
			}
			double TF = calTF(sepWords);
			SearchResult sr = new SearchResult(matchingInfo,TF);
			searchResultList.add(sr);
		}
	}
	
	public ArrayList<SearchResult> sortByTF(){
		SearchResultComparator comparator = new SearchResultComparator();
		Collections.sort(searchResultList, comparator);
		return searchResultList;
	}
}
