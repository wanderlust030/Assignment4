import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DataReader {
	private String dbDriver = "com.mysql.jdbc.Driver"; 
	private String dbUrl = "jdbc:mysql://127.0.0.1:3306/my_schema?";
	private String dbUser = "root";
	private String dbPasswd = "123456";
	
	public Connection getConn(String dbUrl,String dbUser,String dbPasswd){
        Connection conn=null;  
        try{  
            Class.forName(dbDriver);  
        }catch (ClassNotFoundException e){  
            e.printStackTrace();  
            return null;
        }try{  
            conn = DriverManager.getConnection(dbUrl,dbUser,dbPasswd);  
        }catch (SQLException e){  
            e.printStackTrace();
            return null;
        }  
        return conn;  
	}
	
	public ArrayList<ProfessorInfo> readData(){
		Connection conn = null;
		ArrayList<ProfessorInfo> infos = new ArrayList<ProfessorInfo>();
		try{
			conn = getConn(dbUrl,dbUser,dbPasswd);
			String sql = "SELECT * FROM 2014302580147_professor_info";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				ProfessorInfo professorInfo = new ProfessorInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				infos.add(professorInfo);
			}
		}catch(SQLException e){
            e.printStackTrace();
        }finally{
            try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        }
		return infos;
	}
}
