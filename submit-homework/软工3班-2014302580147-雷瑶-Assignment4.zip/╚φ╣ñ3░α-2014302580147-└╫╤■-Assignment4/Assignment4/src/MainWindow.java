import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class MainWindow extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	private String input;
	private KeywordsProcessor kwdsProcessor = new KeywordsProcessor();
	private DataReader dataReader = new DataReader();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 451, 342);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(10, 10, 215, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 41, 425, 262);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
	        	textArea.setText(" ");
				input = textField.getText();//��ȡtextField�������ֵ
				try {
					kwdsProcessor.getStopwords();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				kwdsProcessor.KeywordsExcludeStopwords(input);
				ArrayList<ProfessorInfo> infos = dataReader.readData();
				kwdsProcessor.getMatchingInfos(infos);
				kwdsProcessor.getAllTF();
				ArrayList<SearchResult> searchResultList = new ArrayList<SearchResult>();
				searchResultList = kwdsProcessor.sortByTF();
				
				ArrayList<String> outputList = new ArrayList<String>();
				String output = "";
		        if(searchResultList!=null && searchResultList.size()>0){
		            for(SearchResult sr:searchResultList){
		               String name = "Name:"+sr.getPi().getName();
		               String educationBackground = "EducationBackground:"+sr.getPi().getEducationBackground();
		               String researchInterests = "ResearchInterests:"+sr.getPi().getResearchInterests();
		               String email = "Email:"+sr.getPi().getEmail();
		               String phone = "Phone:"+sr.getPi().getPhone();
		               outputList.add(name+"\r\n"+educationBackground+"\r\n"+researchInterests+"\r\n"
		            		   		+email+"\r\n"+phone+"\r\n"+"__________________________________"+"\r\n");
		            }
		            for(String s:outputList){
		            	output += s;
		            }
		               textArea.setText(output);
		               outputList.clear();
		               output = null;
		        }else{
		        	textArea.setText("No Matching Results!");
		        }
			}
		});
		btnSearch.setBounds(281, 9, 93, 23);
		contentPane.add(btnSearch);
	}
}
