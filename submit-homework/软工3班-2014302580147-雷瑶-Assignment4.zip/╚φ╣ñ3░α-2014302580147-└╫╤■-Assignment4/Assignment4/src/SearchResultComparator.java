import java.util.Comparator;

public class SearchResultComparator implements Comparator<SearchResult>{

	@Override
	public int compare(SearchResult o1, SearchResult o2) {
		double TF1 = o1.getTF();
		double TF2 = o2.getTF();
		if(TF1 > TF2){
			return -1;
		}else if(TF1 < TF2){
			return 1;
		}else return 0;
	}

}