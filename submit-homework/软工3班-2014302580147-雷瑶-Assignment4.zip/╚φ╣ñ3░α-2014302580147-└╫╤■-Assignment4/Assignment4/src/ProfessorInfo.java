
public class ProfessorInfo {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEducationBackground() {
		return educationBackground;
	}

	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}

	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public ProfessorInfo(String name,String educationBackground,String researchInterests,
			String email,String phone){
		super();
		this.name = name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.email = email;
		this.phone = phone;
	}
}
